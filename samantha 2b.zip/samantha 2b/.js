const canvas = document.getElementById('canvas');
const ctx = canvas.GetContext('2d');

function resize(){
    canvas.width = Window.innerWhidth / 2 ;
    canvas.height = window.innerHeight / 2;
};
window.addEventListener('resize', resize);
resize();

function noise(){
    const w = canvas.width;
    const h = canvas.height;
    const imgData = ctx.createImageData(w, h);
    const data = imgData.data;

for (let i = 0; i < data.length; i += 4) {
    const shard = Math.floor(Math.random() * 255);
    data[i] = shard;     
    data[i + 1] = shard; 
    data[i + 2] = shard; 
    data[i + 3] = 255;  
  }
  ctx.putImageData(imgData, 0, 0);
  requestAnimationFrame(noise);
}
noise();

